// Mobile Navigation Toggle
document.addEventListener('DOMContentLoaded', function() {
    const navToggle = document.querySelector('.nav-toggle');
    const navList = document.querySelector('.nav-list');
    
    navToggle.addEventListener('click', function() {
        navList.classList.toggle('active');
        this.classList.toggle('active');
    });
    
    // Close mobile menu when clicking on a link
    const navLinks = document.querySelectorAll('.nav-list a');
    navLinks.forEach(link => {
        link.addEventListener('click', function() {
            navList.classList.remove('active');
            navToggle.classList.remove('active');
        });
    });
    
    // Smooth scrolling for anchor links
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function(e) {
            e.preventDefault();
            
            const targetId = this.getAttribute('href');
            if (targetId === '#') return;
            
            const targetElement = document.querySelector(targetId);
            if (targetElement) {
                window.scrollTo({
                    top: targetElement.offsetTop - 70,
                    behavior: 'smooth'
                });
            }
        });
    });
    
    // Add active class to current page link
    const currentPage = location.pathname.split('/').pop();
    const navItems = document.querySelectorAll('.nav-list a');
    
    navItems.forEach(item => {
        const itemHref = item.getAttribute('href');
        if (itemHref === currentPage) {
            item.classList.add('active');
        }
    });
});

// Tech Stack Carousel
class TechCarousel {
    constructor() {
        this.carousel = document.querySelector('.carousel');
        this.track = document.querySelector('.carousel-track');
        this.items = [];
        this.currentIndex = 0;
        this.autoPlayInterval = null;
        
        if (this.carousel) {
            this.init();
        }
    }
    
    async init() {
        await this.loadTechStack();
        this.render();
        this.setupControls();
        this.startAutoPlay();
    }
    
    async loadTechStack() {
        try {
            const response = await fetch('data/techstack.json');
            const data = await response.json();
            this.items = data.technologies;
        } catch (error) {
            console.error('Error loading tech stack:', error);
        }
    }
    
    render() {
        this.track.innerHTML = this.items.map(tech => `
            <div class="tech-item">
                <i class="${tech.icon} tech-icon" style="color: ${tech.color}"></i>
                <span class="tech-name">${tech.name}</span>
            </div>
        `).join('');
        
        this.updatePips();
    }
    
    setupControls() {
        const prevBtn = this.carousel.querySelector('.carousel-prev');
        const nextBtn = this.carousel.querySelector('.carousel-next');
        const pips = this.carousel.querySelectorAll('.pip');
        
        prevBtn.addEventListener('click', () => this.prevSlide());
        nextBtn.addEventListener('click', () => this.nextSlide());
        
        pips.forEach((pip, index) => {
            pip.addEventListener('click', () => this.goToSlide(index));
        });
        
        // Keyboard navigation
        document.addEventListener('keydown', (e) => {
            if (e.key === 'ArrowLeft') this.prevSlide();
            if (e.key === 'ArrowRight') this.nextSlide();
        });
        
        // Touch events for mobile
        let touchStartX = 0;
        let touchEndX = 0;
        
        this.track.addEventListener('touchstart', (e) => {
            touchStartX = e.changedTouches[0].screenX;
        }, {passive: true});
        
        this.track.addEventListener('touchend', (e) => {
            touchEndX = e.changedTouches[0].screenX;
            this.handleSwipe();
        }, {passive: true});
    }
    
    handleSwipe() {
        const swipeThreshold = 50;
        if (touchStartX - touchEndX > swipeThreshold) {
            this.nextSlide();
        } else if (touchEndX - touchStartX > swipeThreshold) {
            this.prevSlide();
        }
    }
    
    nextSlide() {
        this.currentIndex = (this.currentIndex + 1) % this.items.length;
        this.updateSlide();
        this.resetAutoPlay();
    }
    
    prevSlide() {
        this.currentIndex = (this.currentIndex - 1 + this.items.length) % this.items.length;
        this.updateSlide();
        this.resetAutoPlay();
    }
    
    goToSlide(index) {
        this.currentIndex = index;
        this.updateSlide();
        this.resetAutoPlay();
    }
    
    updateSlide() {
        const itemWidth = 150 + 32; // width + margin
        const offset = -this.currentIndex * itemWidth;
        this.track.style.transform = `translateX(${offset}px)`;
        this.updatePips();
    }
    
    updatePips() {
        const pips = this.carousel.querySelectorAll('.pip');
        pips.forEach((pip, index) => {
            pip.classList.toggle('active', index === this.currentIndex);
        });
    }
    
    startAutoPlay() {
        this.autoPlayInterval = setInterval(() => this.nextSlide(), 3000);
        
        // Pause on hover
        this.carousel.addEventListener('mouseenter', () => {
            clearInterval(this.autoPlayInterval);
        });
        
        this.carousel.addEventListener('mouseleave', () => {
            this.resetAutoPlay();
        });
    }
    
    resetAutoPlay() {
        clearInterval(this.autoPlayInterval);
        this.autoPlayInterval = setInterval(() => this.nextSlide(), 3000);
    }
}

// Initialize when DOM loads
document.addEventListener('DOMContentLoaded', () => {
    new TechCarousel();
});