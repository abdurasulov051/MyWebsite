document.addEventListener('DOMContentLoaded', function() {
    // Load gallery data from JSON
    fetch('data/gallery.json')
        .then(response => response.json())
        .then(data => {
            const gallery = document.getElementById('gallery');
            
            // Create gallery items
            data.images.forEach(image => {
                const galleryItem = document.createElement('div');
                galleryItem.className = `gallery-item ${image.category}`;
                galleryItem.dataset.category = image.category;
                
                const link = document.createElement('a');
                link.href = image.fullSize;
                link.setAttribute('data-lightbox', 'gallery');
                link.setAttribute('aria-label', `View ${image.title} in larger size`);
                
                const img = document.createElement('img');
                img.src = image.src;
                img.alt = image.alt;
                img.loading = 'lazy';
                
                const overlay = document.createElement('div');
                overlay.className = 'gallery-overlay';
                
                const title = document.createElement('h3');
                title.textContent = image.title;
                
                const category = document.createElement('span');
                category.className = 'gallery-category';
                category.textContent = image.category;
                
                overlay.appendChild(title);
                overlay.appendChild(category);
                link.appendChild(img);
                link.appendChild(overlay);
                galleryItem.appendChild(link);
                gallery.appendChild(galleryItem);
            });
            
            // Filter functionality
            const filterButtons = document.querySelectorAll('.filter-btn');
            filterButtons.forEach(button => {
                button.addEventListener('click', function() {
                    // Update active button
                    filterButtons.forEach(btn => btn.classList.remove('active'));
                    this.classList.add('active');
                    
                    const filter = this.dataset.filter;
                    const galleryItems = document.querySelectorAll('.gallery-item');
                    
                    galleryItems.forEach(item => {
                        if (filter === 'all' || item.dataset.category === filter) {
                            item.style.display = 'block';
                        } else {
                            item.style.display = 'none';
                        }
                    });
                });
            });
        })
        .catch(error => {
            console.error('Error loading gallery:', error);
            document.getElementById('gallery').innerHTML = 
                '<p class="error">Unable to load gallery. Please try again later.</p>';
        });
});