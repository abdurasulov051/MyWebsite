class Carousel {
    constructor(container, dataUrl) {
        this.container = document.querySelector(container);
        this.dataUrl = dataUrl;
        this.slides = [];
        this.currentIndex = 0;
        this.interval = null;
        this.init();
    }
    
    async init() {
        await this.loadSlides();
        this.render();
        this.setupControls();
        this.startAutoPlay();
    }
    
    async loadSlides() {
        try {
            const response = await fetch(this.dataUrl);
            const data = await response.json();
            this.slides = data.slides;
        } catch (error) {
            console.error('Error loading carousel data:', error);
            this.container.innerHTML = 
                '<p class="error">Unable to load carousel. Please try again later.</p>';
        }
    }
    
    render() {
        this.container.innerHTML = `
            <div class="carousel-container">
                <div class="carousel-track">
                    ${this.slides.map((slide, index) => `
                        <div class="carousel-slide ${index === 0 ? 'active' : ''}">
                            <img src="${slide.src}" alt="${slide.alt}" loading="lazy">
                            <div class="slide-content">
                                <h3>${slide.title}</h3>
                                <p>${slide.description}</p>
                            </div>
                        </div>
                    `).join('')}
                </div>
                
                <button class="carousel-btn carousel-prev" aria-label="Previous slide">❮</button>
                <button class="carousel-btn carousel-next" aria-label="Next slide">❯</button>
                
                <div class="carousel-pips">
                    ${this.slides.map((_, index) => `
                        <button class="pip ${index === 0 ? 'active' : ''}" 
                                data-index="${index}" 
                                aria-label="Go to slide ${index + 1}"></button>
                    `).join('')}
                </div>
            </div>
        `;
    }
    
    setupControls() {
        const prevBtn = this.container.querySelector('.carousel-prev');
        const nextBtn = this.container.querySelector('.carousel-next');
        const pips = this.container.querySelectorAll('.pip');
        
        prevBtn.addEventListener('click', () => this.prevSlide());
        nextBtn.addEventListener('click', () => this.nextSlide());
        
        pips.forEach(pip => {
            pip.addEventListener('click', () => {
                this.goToSlide(parseInt(pip.dataset.index));
            });
        });
        
        // Keyboard navigation
        document.addEventListener('keydown', (e) => {
            if (e.key === 'ArrowLeft') this.prevSlide();
            if (e.key === 'ArrowRight') this.nextSlide();
        });
    }
    
    updateSlide() {
        const slides = this.container.querySelectorAll('.carousel-slide');
        const pips = this.container.querySelectorAll('.pip');
        
        slides.forEach((slide, index) => {
            slide.classList.toggle('active', index === this.currentIndex);
        });
        
        pips.forEach((pip, index) => {
            pip.classList.toggle('active', index === this.currentIndex);
        });
    }
    
    nextSlide() {
        this.currentIndex = (this.currentIndex + 1) % this.slides.length;
        this.updateSlide();
        this.resetAutoPlay();
    }
    
    prevSlide() {
        this.currentIndex = (this.currentIndex - 1 + this.slides.length) % this.slides.length;
        this.updateSlide();
        this.resetAutoPlay();
    }
    
    goToSlide(index) {
        this.currentIndex = index;
        this.updateSlide();
        this.resetAutoPlay();
    }
    
    startAutoPlay() {
        this.interval = setInterval(() => this.nextSlide(), 5000);
        
        // Pause on hover
        this.container.addEventListener('mouseenter', () => {
            clearInterval(this.interval);
        });
        
        this.container.addEventListener('mouseleave', () => {
            this.resetAutoPlay();
        });
    }
    
    resetAutoPlay() {
        clearInterval(this.interval);
        this.interval = setInterval(() => this.nextSlide(), 5000);
    }
}

// Initialize carousel on page load
document.addEventListener('DOMContentLoaded', function() {
    if (document.querySelector('.carousel')) {
        new Carousel('.carousel', 'data/carousel.json');
    }
});